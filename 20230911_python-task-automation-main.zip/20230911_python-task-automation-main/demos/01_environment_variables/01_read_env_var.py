# provides access to operating system functions
import os


def main() -> None:
    # environment variables are available on a dictionary
    home = os.environ["HOME"]
    print(f"Env Var: HOME={home}")
    # SAMPLE=fun python ./01_environment_variables/01_read_env_var.py
    sample = os.environ["SAMPLE"]
    print(f"Env Var: SAMPLE={sample}")


if __name__ == "__main__":
    main()
