# provides access to operating system functions
import os

# install the `python-dotenv` package
# python -m pip install python-dotenv
# conda install -y python-dotenv
# micromamba install -y python-dotenv

from dotenv import load_dotenv


def main() -> None:
    # Loads environment variables from a .env file into the current environment.
    # This function is part of the python-dotenv library, which is used to manage
    # environment variables in Python projects.
    load_dotenv()

    home = os.environ["HOME"]
    print(f"Env Var: HOME={home}")
    sample = os.environ["SAMPLE"]
    print(f"Env Var: SAMPLE={sample}")


if __name__ == "__main__":
    main()
