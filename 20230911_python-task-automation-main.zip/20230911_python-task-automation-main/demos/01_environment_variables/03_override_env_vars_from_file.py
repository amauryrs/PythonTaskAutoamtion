# provides access to operating system functions
import os


from dotenv import load_dotenv


def main() -> None:
    # Setting `override` to True will override the existing environment
    # variables from the system
    load_dotenv(override=True)

    home = os.environ["HOME"]
    print(f"Env Var: HOME={home}")
    sample = os.environ["SAMPLE"]
    print(f"Env Var: SAMPLE={sample}")


if __name__ == "__main__":
    main()
